function [f,g] = LinearRegression(input,XX,y)
% w(feature,1)
% X(instance,feature)
% y(instance,1)


    [D K]=size(XX);
    [D N]=size(y);
    % Use 2 matrix-vector products with X
    
    A=DblVec2Matrix(input, 1, N*K,N,K);
    

	sigma_1=exp(input((K)*N+1,1));
   
    disp(sigma_1);
   
    
    X=XX';
    Z=y';    
    Sigma = zeros(N,N);
		

	I_N = eye(N);
    
	Sigma = sigma_1*sigma_1*I_N;

    Sigma_inverse=inv(Sigma);

	f = 0;
    secondPart = 0;

	T=Z-A*X;
	for d = 1:1:D		
			temp = T(:,d)'*Sigma_inverse*T(:,d);
			secondPart=secondPart+temp;
    end
	f=D/2.0*logdet(Sigma)+1/2.0*secondPart;
    disp(f);
    g1=zeros(N,K);
	g2=zeros(1,1);
	for d=1:1:D
		x_d = X(:,d);
		z_d = Z(:,d);
		t_d=T(1:N,d);
	    Sigma_i_t_d = Sigma_inverse*t_d;
		phi_d = 1/2.0*(Sigma_inverse-Sigma_i_t_d*Sigma_i_t_d');
		g1 = g1-1*(Sigma_i_t_d*x_d');

		g2=g2+2*sigma_1*trace(phi_d);
    end

	g2=g2*(sigma_1);

        g=[];
    
    g11=reshape(g1,size(g1,1)*size(g1,2),1);
    g22=reshape(g2,size(g2,1)*size(g2,2),1);
%     g33=reshape(g3,size(g3,1)*size(g3,2),1);
%     g44=reshape(g4,size(g4,1)*size(g4,2),1);
%     g55=reshape(g5,size(g5,1)*size(g5,2),1);
    
    g=[g; g11];
    g=[g; g22];
    
%     g=[g; g33];
%     g=[g; g44];
%     g=[g; g55];  

end