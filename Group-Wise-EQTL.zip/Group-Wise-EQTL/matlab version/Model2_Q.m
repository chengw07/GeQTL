function [f,g] = Model2_Q(input,XX,y,M,H)
% w(feature,1)
% X(instance,feature)
% y(instance,1)

    [D K]=size(XX);
    [D N]=size(y);
    % Use 2 matrix-vector products with X
    
    A=DblVec2Matrix(input, 1, M*K,M,K);
    B=DblVec2Matrix(input, M*K+1, M*N+M*K,N,M);
    C=DblVec2Matrix(input, M*N+M*K+1, M*N+M*K+N*K,N,K);
    Q=DblVec2Matrix(input, M*N+M*K+N*K+1, (H+M)*N+M*K+N*K,N,H);
    %tau=exp(input((K)*M+(M)*N+1,1));
    
	%sigma_1=exp(input((K)*M+(M)*N+1,1));
    sigma_1=0.04;
    %sigma_2=exp(input((K)*M+(M)*N+2,1));
    sigma_2=0.04;
  %  disp(tau);
%    disp(sigma_1);
 %   disp(sigma_2);
    

   % g = 2*(X.'*res);
    
    X=(standardizeCols(XX))';
    Z=y';    
    Sigma = zeros(N,N);
		

	I_N = eye(N);
    B_B_t = B*B';
	Sigma = sigma_1*sigma_1*B_B_t +sigma_2*sigma_2*I_N+Q*Q';

    Sigma_inverse=inv(Sigma);

	f = 0;
    secondPart = 0;
	x_avg=sum(X,2)/D;
    
	z_avg=sum(Z,2)/D;
	
	for d = 1:1:D
			x_avg = x_avg+1.0/D*X(:,d);
			z_avg = z_avg+1.0/D*Z(:,d);
    end
	allOne=ones(1,D);
	
	T=zeros(N,D);
	T=Z-z_avg*allOne-(B*A+C)*(X-x_avg*allOne);
	for d = 1:1:D		
			temp = T(:,d)'*Sigma_inverse*T(:,d);
			secondPart=secondPart+temp;
    end
	f=D/2.0*logdet(Sigma)+1/2.0*secondPart;
    disp(f);
    g1=zeros(M,K);
	g2=zeros(N,M);
    g3=zeros(N,K);
    
% 	g4=zeros(1,1);
%   g4=zeros(1,1);
% 	g5=zeros(1,1);
    g6=zeros(N,H);
	for d=1:1:D
		x_d = X(:,d);
		z_d = Z(:,d);
		t_d=T(1:N,d);
	    Sigma_i_t_d = Sigma_inverse*t_d;
		phi_d = 1/2.0*(Sigma_inverse-Sigma_i_t_d*Sigma_i_t_d');
        g1 = g1-1*(B'*Sigma_i_t_d*(x_d-x_avg)');
        Xi_1 = -1*Sigma_i_t_d*(x_d-x_avg)'*A';
		Xi_2=2*sigma_1*sigma_1*phi_d*B;
		
		g2=g2+Xi_1+Xi_2;
        
        g3=g3-Sigma_i_t_d*(x_d-x_avg)';
%        g4=g4+2*tau*trace(phi_d*Kin);
%        g4=g4+2*sigma_1*trace(phi_d*B_B_t);
%		g5=g5+2*sigma_2*trace(phi_d);
        g6=g6+2*phi_d*Q;
    end

%	g4=g4*(tau);
    %g4=g4*(sigma_1);
%	g5=g5*(sigma_2);


        g=[];
    
    g11=reshape(g1,size(g1,1)*size(g1,2),1);
    g22=reshape(g2,size(g2,1)*size(g2,2),1);
    g33=reshape(g3,size(g3,1)*size(g3,2),1);
%     g44=reshape(g4,size(g4,1)*size(g4,2),1);
%     g55=reshape(g5,size(g5,1)*size(g5,2),1);
    g66=reshape(g6,size(g6,1)*size(g6,2),1);
    g=[g; g11];
    g=[g; g22];
    
    g=[g; g33];
%     g=[g; g44];
%     g=[g; g55];  
   g=[g; g66];   

end