function [f,g] = SquaredError2(wLASSO,X,y)
% w(feature,1)
% X(instance,feature)
% y(instance,1)


    % Use 2 matrix-vector products with X
    w=DblVec2Matrix(wLASSO, 1, 10000,100,100);
    Xw = X*w;
    res = Xw-y;
    f = sum(sum(res.^2));


   % g = 2*(X.'*res);
    
    XX=X';
    Z=y';
    W=w';
	g=[];
	g1=-2*Z*XX'+2*W*XX*XX';
    [Nrows Ncols]=size(g1);

    for j=1:1:Ncols
			for i=1:1:Nrows	
				g = [g; g1(i,j)];
            end
    end

end