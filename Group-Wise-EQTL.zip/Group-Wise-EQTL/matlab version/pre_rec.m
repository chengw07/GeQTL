addpath(genpath(pwd));
W=eye(100);
for i=10:25
    for j=10:25
        W(i,j)=1;
    end
end

for i=30:40
    for j=30:40
        W(i,j)=1;
    end
end

for i=50:55
    for j=50:55
        W(i,j)=1;
    end
end

for i=60:80
    for j=60:64
        W(i,j)=1;
    end
end

weight=1;
W=weight*W;

hidden_num = 10;
D=80;
Hidden=randn(D,hidden_num);
eta=1;
Sigma= eta*Hidden*Hidden';
mu=zeros(1,D);
MU=[];
for i=1:100
    r = mvnrnd(mu,Sigma,1);
    MU=[MU;r];
end

%%%%%%%%%%%  errors
rho = 0.01;
E=sqrt(rho) * randn(100,D);

%%%%%%%%%%%   X
X=load('mD.txt');
X=X(1:100,1:80);

%%%%%%%%%%%  Z
Z=W*X+MU+E;

% X=load('X.txt');
% Z=load('Z.txt');

% XX=standardizeCols(X');
% X=XX';

% LASSO 
[K D]=size(X);
[N D]=size(Z);

H=10;
M=80;
weight_A=2500;
weight_B=2500;
weight_Q=3000;
dim = (K)*M+(M+H)*N;
lambda=[];
partA=ones(K*M,1)*weight_A;
partB=ones(N*M,1)*weight_B;
partQ=ones(N*H,1)*weight_Q;

lambda=[partA;partB;partQ];
%Kin = cov(Z');
funObj = @(w)Model1_Q(w,X',Z',M,H); % Loss function that L1 regularization is applied to
w_init = rand(dim,1); % Initial value for iterative optimizer
wLASSO = L1General2_OWL(funObj,w_init,lambda);
A=DblVec2Matrix(wLASSO, 1, K*M,M,K);
B=DblVec2Matrix(wLASSO, K*M+1, K*M+N*M,N,M);
Q=DblVec2Matrix(wLASSO, K*M+N*M+1, (K)*M+(M+H)*N,N,H);

weight_A=1800;
weight_B=1800;
weight_C=1800;
dim = (K)*M+(M+H)*N+K*N;
lambda=[];
partA=ones(K*M,1)*weight_A;
partB=ones(N*M,1)*weight_B;
partC=ones(N*K,1)*weight_C;
partQ=ones(N*H,1)*weight_Q;
lambda=[partA;partB;partC;partQ];
%Kin = cov(Z');
funObj = @(w)Model2_Q(w,X',Z',M,H); % Loss function that L1 regularization is applied to
w_init = rand(dim,1); % Initial value for iterative optimizer
wLASSO_2 = L1General2_OWL(funObj,w_init,lambda);
A_2=DblVec2Matrix(wLASSO_2, 1, K*M,M,K);
B_2=DblVec2Matrix(wLASSO_2, K*M+1, K*M+N*M,N,M);
C_2=DblVec2Matrix(wLASSO_2, M*N+M*K+1, M*N+M*K+N*K,N,K);
Q_2=DblVec2Matrix(wLASSO_2, M*N+M*K+N*K+1, (K)*M+(M+H)*N+K*N,N,H);


cd C:/Users/weicheng/Dropbox/NIPS2013/lasso;
[ result ] = LassoMatrix(X,Z,7);



pre1=[];
pre2=[];
pre3=[];
rec2=[];
rec1=[];
rec3=[];
W(W>0)=1;
for i=[0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 0.999999]
W11=abs(B*A);
    W22=abs(B_2*A_2+C_2);
    W33=abs(result);
W11=W11/max(max(W11));
W22=W22/max(max(W22));
W33=W33/max(max(W33));
W11(W11>i)=1;
    W22(W22>i)=1;
    W33(W33>i)=1;
W11(W11<=i)=0;
    W22(W22<=i)=0;
    W33(W33<i)=0;
    pre1=[pre1 sum(sum(W&W11))/sum(sum(W11))];
    rec1=[rec1 sum(sum(W&W11))/sum(sum(W))];
    pre2=[pre2 sum(sum(W&W22))/sum(sum(W22))];
    rec2=[rec2 sum(sum(W&W22))/sum(sum(W))];
    pre3=[pre3 sum(sum(W&W33))/sum(sum(W33))];
    rec3=[rec3 sum(sum(W&W33))/sum(sum(W))];
end
figure;
plot(pre1,rec1,'--b*');
hold on;
plot(pre2,rec2,'--rx');
plot(pre3,rec3,'--blacko');
xlabel('precision','Fontname','Times New Roman','Fontsize',18);
ylabel('recall','Fontname','Times New Roman','Fontsize',18);
set(gca,'LineWidth',2,'Fontname','Times New Roman','Fontsize',12);
name=sprintf('%s%d','hidden\_num=',hidden_num);
title(name);
cd C:\Users\weicheng\Desktop\bioinformatics\L1General\L1GeneralExamples;