function [ M_res ] = resizeMatrix( M,row,col )
[r,c]=size(M);
if r < row
    M_res=M;
    return;
end
if c < col
    M_res = M;
    return;
end
a=floor(r/row);
b=floor(c/col);

a2=ceil(r/row);
b2=ceil(c/col);

M_res=zeros(a2,b2);

for i=1:a2
    for j=1:b2
        temp=size(row,col);
        if(i==a2 && j==b2)
            temp=M((i-1)*row+1:end,(j-1)*col+1:end);
        elseif(i==a2)
            temp=M((i-1)*row+1:end,(j-1)*col+1:j*col);
        elseif(j==b2)
            temp=M((i-1)*row+1:i*row,(j-1)*col+1:end);
        else
            temp=M((i-1)*row+1:i*row,(j-1)*col+1:j*col);
        end
        if(i==j)
        M_res(i,j)=mean(mean(temp));
        else
            M_res(i,j)=mean(mean(temp));
        end
    end
end
end

