function v = calculateKin(Z)

	Z_t = Z';
	result=sum(Z_t,1);
	result=result/size(Z_t,1);
	Z_t_avg = result;
	onesZ=ones(size(Z_t,1),1);
	
	Z_return=Z_t-onesZ*Z_t_avg;
	v=Z_return'*Z_return/(size(Z,2)-1.0);
end