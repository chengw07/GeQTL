addpath(genpath(pwd));
W=eye(100);
for i=10:25
    for j=10:25
        W(i,j)=1;
    end
end

for i=30:40
    for j=30:40
        W(i,j)=1;
    end
end

for i=50:55
    for j=50:55
        W(i,j)=1;
    end
end

for i=60:80
    for j=60:64
        W(i,j)=1;
    end
end

hidden_num = 10;
D=80;
H=randn(D,hidden_num);
tau=0.01;
Sigma= tau*H*H';
mu=zeros(1,D);
MU=[];
for i=1:100
    r = mvnrnd(mu,Sigma,1);
    MU=[MU;r];
end

%%%%%%%%%%%  errors
gamma_e = 0.01;
E=sqrt(gamma_e) * randn(100,D);

%%%%%%%%%%%   X
X=load('mD.txt');
X=X(1:100,1:80);

%%%%%%%%%%%  Z
Z=W*X+MU+E;

% X=load('X.txt');
% Z=load('Z.txt');

% XX=standardizeCols(X');
% X=XX';

% LASSO 
[K D]=size(X);
[N D]=size(Z);

sample_size = D/2;
X_train=X(:,1:sample_size);
X_test=X(:,sample_size+1:end);
Z_train=Z(:,1:sample_size);
Z_test=Z(:,sample_size+1:end);
params = CV_model1( X_train, Z_train, X_test, Z_test );


M=params(1);
weight_A=params(2);
weight_B=params(3);
dim = (K)*M+(M)*N;
lambda=[];
for i=1:K*M
    lambda=[lambda; weight_A];
end
for i=1:M*N
    lambda=[lambda; weight_B];
end
%lambda=[lambda; 0];
%lambda=[lambda; 0];
%lambda=[lambda; 0];

Kin = cov(Z');
funObj = @(w)Model1(w,X',Z',M,Kin); % Loss function that L1 regularization is applied to
w_init = rand(dim,1); % Initial value for iterative optimizer
wLASSO = L1General2_OWL(funObj,w_init,lambda);
A=DblVec2Matrix(wLASSO, 1, K*M,M,K);
B=DblVec2Matrix(wLASSO, K*M+1, K*M+N*M,N,M);
%tau=exp(wLASSO(K*M+N*M+1,1));
%sigma_1=exp(wLASSO(K*M+N*M+2,1));
%sigma_2=exp(wLASSO(K*M+N*M+2,1));

%disp(tau);
% disp(sigma_1);
%disp(sigma_2);


params_C = CV_model2 ( X_train, Z_train, X_test, Z_test );
M=params_C(1);
weight_A=params_C(2);
weight_B=params_C(3);
weight_C=params_C(4);
dim = (K)*M+(M)*N+K*N;
lambda=[];
for i=1:K*M
    lambda=[lambda; weight_A];
end
for i=1:M*N
    lambda=[lambda; weight_B];
end
for i=1:K*N
    lambda=[lambda; weight_C];
end
%lambda=[lambda; 0];
%lambda=[lambda; 0];
%lambda=[lambda; 0];

Kin = cov(Z');
funObj = @(w)Model2(w,X',Z',M,Kin); % Loss function that L1 regularization is applied to
w_init = rand(dim,1); % Initial value for iterative optimizer
wLASSO_2 = L1General2_OWL(funObj,w_init,lambda);
A_2=DblVec2Matrix(wLASSO_2, 1, K*M,M,K);
B_2=DblVec2Matrix(wLASSO_2, K*M+1, K*M+N*M,N,M);
C_2=DblVec2Matrix(wLASSO_2, M*N+M*K+1, M*N+M*K+N*K,N,K);
%tau_2=exp(wLASSO_2(M*N+M*K+N*K+1,1));
%sigma_1=exp(wLASSO(K*M+N*M+2,1));
%sigma_2_2=exp(wLASSO_2(M*N+M*K+N*K+2,1));




figure;
subplot(2,2,1);
imshow(abs((abs(W))));
title('ground truth');
C2=colormap(hot);
colormap(1-C2);
set(gca, 'CLim', [0 1]);
colorbar;

subplot(2,2,2);
imshow(abs((abs(B*A))));
title('Model1 B*A');
C2=colormap(hot);
colormap(1-C2);
set(gca, 'CLim', [0 1]);
colorbar;

subplot(2,2,3);
imshow(abs((abs(B_2*A_2))));
title('Model2 B*A');
C2=colormap(hot);
colormap(1-C2);
set(gca, 'CLim', [0 1]);
colorbar;

subplot(2,2,4);
imshow(abs((abs(B_2*A_2+C_2))));
title('Model2 B*A+C');
C2=colormap(hot);
colormap(1-C2);
set(gca, 'CLim', [0 1]);
colorbar;
