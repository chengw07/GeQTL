function [ res ] = rowNormalize( M )
[r,c]=size(M);
res=M;
for i=1:r
    sum_r = sum(sum(res(i,:)));
    if(sum_r~=0)
        res(i,:)=res(i,:)/sum_r;
    end
end


end

