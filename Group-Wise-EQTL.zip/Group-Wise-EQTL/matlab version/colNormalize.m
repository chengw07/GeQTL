function [ res ] = colNormalize( M )
[r,c]=size(M);
res=M;
for i=1:c
    sum_c = sum(sum(res(:,i)));
    if(sum_c~=0)
        res(:,i)=res(:,i)/sum_c;
    end
end


end

