function [PREC, REC, AUC]=roc_curve_prec_rec(B, S0)

    PREC = [];
    REC = [];

    for th = linspace(-eps,max(abs(B(:)))+eps,100)
        S = abs(B) > th;
        PREC = [PREC;sum(S(:)&S0(:))/(sum(S(:))+eps)];
        REC = [REC;sum(S(:)&S0(:))/(sum(S0(:))+eps)];
    end

    AUC = sum((REC(1:end-1)-REC(2:end)).*(PREC(1:end-1)+PREC(2:end))/2);
end