#pragma once

#include <fstream>
#include <string>

#include "OWLQN.h"
#include "newmatap.h"                // need matrix applications

void printDblVec(const DblVec &v);

void printMatrix(const Matrix& A);

void DblVec2Matrix(const DblVec& vec, const int k1, const int k2, Matrix& A);

void printMatrix2(Matrix& matrix);


class TwoLayerLinearRegression
{
	Matrix Z;
	Matrix X;
	Matrix Kin;
	size_t N,K,D,M,H;

	friend struct TwoLayerLinearRegressionObjective;

public:
	TwoLayerLinearRegression(size_t N, size_t K, size_t D, size_t M, size_t H) : X(K,D), Z(N,D), N(N), K(K), D(D), M(M),H(H) { }

	TwoLayerLinearRegression(const char* Xfile, const char* ZFile, int M,int H);

	size_t NumInstances() const { return D; }	
	size_t NumSNPs() const { return K; }
	size_t NumGENs() const { return N; }
	size_t NumHiddenVs() const { return M; }
	Matrix getKin() {return Kin;}
	Matrix calculateKin(Matrix Z);
	double output_matrices();
	void randomMatrix(Matrix &matrix);
};


struct TwoLayerLinearRegressionObjective : public DifferentiableFunction 
{
	const TwoLayerLinearRegression& problem;

	TwoLayerLinearRegressionObjective(const TwoLayerLinearRegression& p) : problem(p) { }

	double Eval(const DblVec& input, DblVec& gradient);

};


