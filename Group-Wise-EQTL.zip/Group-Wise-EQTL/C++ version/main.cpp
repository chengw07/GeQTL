//$$ example.cpp                             Example of use of matrix package

//#define WANT_STREAM                  // include.h will get stream fns
#define WANT_MATH                    // include.h will get math fns
                                     // newmatap.h will get include.h
#include <iostream>
#include <vector>
#include <deque>
#include <fstream>
#include <ctime> 
#include <cstdlib>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>


#include "OWLQN.h"
#include "leastSquares.h"
#include "logreg.h"

#include "TwoLayerLinearRegression.h"

#include "newmatap.h"                // need matrix applications
//#include "newmatio.h"                // need matrix output routines

//#ifdef use_namespace
//using namespace NEWMAT;              // access NEWMAT namespace
//#endif

using namespace std;

// demonstration of matrix package on linear regression problem


void printUsageAndExit() {
	cout << "Orthant-Wise Limited-memory Quasi-Newton trainer" << endl;
	cout << "trains L1-regularized logistic regression or least-squares models" << endl << endl;
	cout << "usage: feature_file label_file regWeight output_file [options]" << endl;
	cout << "  feature_file   input feature matrix in Matrix Market format (mxn real coordinate or array)" << endl;
	cout << "                   rows represent features for each instance" << endl;
	cout << "  label_file     input instance labels in Matrix Market format (mx1 real array)" << endl;
	cout << "                   rows contain single real value" << endl;
	cout << "                   for logistic regression problems, value must be 1 or -1" << endl;
	cout << "  regWeight      coefficient of l1 regularizer" << endl;
	cout << "  output_file    output weight vector in Matrix Market format (1xm real array)" << endl << endl;
	cout << "options:" << endl;
	cout << "  -ls            use least squares formulation (logistic regression is default)" << endl;
	cout << "  -q             quiet.  Suppress all output" << endl;
	cout << "  -tol <value>   sets convergence tolerance (default is 1e-4)" << endl;
	cout << "  -m <value>     sets L-BFGS memory parameter (default is 10)" << endl;
	cout << "  -l2weight <value>" << endl;
	cout << "                 sets L2 regularization weight (default is 0)" << endl;
	cout << endl;
	exit(0);
}

void printVector(const DblVec &vec, const char* filename) {
	ofstream outfile(filename);
	if (!outfile.good()) {
		cerr << "error opening matrix file " << filename << endl;
		exit(1);
	}
	outfile << "1 " << vec.size() << endl;
	for (size_t i=0; i<vec.size(); i++) {
		outfile << vec[i] << endl;
	}
	outfile.close();
}


void printMatrix2file(const Matrix &A,  const char* filename)
{

	ofstream outfile(filename);

	size_t m = A.Nrows();
	size_t n = A.Ncols();

//	outfile<<"#rows: "<<m<<", #cols: "<<n<<endl;

	for (int i=1;i<=m;i++)
	{
		for (int j=1;j<=n;j++)
		{
			outfile<<" "<<A(i,j)<<" ";
		}
		outfile<<endl;
	}
	outfile<<endl;

	outfile.close();
}

void printMatrix3(Matrix& matrix)
{
	for( int i=1; i<=matrix.Nrows();i++)
	{
		for( int j=1;j<=matrix.Ncols();j++)
		{
			cout<<matrix(i,j)<<" ";
		}
		cout<<endl;
	}


}

void initialize_input(DblVec &input)
{
    srand(5);     
	float random_num;     
	float lowest=-1, highest=1;     
	float range=(highest-lowest)+1;     
	for(int index=0; index<input.size(); index++)
	{         
		random_num = lowest+(range*rand()/(RAND_MAX + 1.0));         
//		cout << random_num << endl;   
		input[index]=random_num;
	} 

}


int matrix_non_zeros(const Matrix& A, double threshold_of_weight)
{

	int non_zeros=0;

	size_t m = A.Nrows();
	size_t n = A.Ncols();

	for (int i=1;i<=m;i++)
	{
		for (int j=1;j<=n;j++)
		{
			if (abs(A(i,j))>threshold_of_weight) 
			{
				non_zeros++;
			}

		}

	}


	return non_zeros;
}


double outsample_test(const char* Test_XFilename, const char* Test_ZFilename, Matrix Kin, const int& M, const DblVec& input)
{
	Matrix Z,X;

	int N,K,D;

	{
		ifstream xfile(Test_XFilename);

		if (!xfile.good()) 
		{
			cerr << "error opening SNPs matrix file " << Test_XFilename << endl;
			exit(1);
		}


		string s;
		getline(xfile, s);

		stringstream st(s);
		st >> K >> D;
		X.ReSize(K,D); 

		////////////////added by wei///////
		//getline(xfile, s);

		for (size_t k=1; k<=K; k++) 
		{
			//string geneName;
			//xfile>>geneName;
			for (size_t d=1; d<=D; d++) 
			{
				float val;
				xfile >> val;
				X(k,d) = val;
			}
		}

		xfile.close();
	}


	{
		ifstream zfile(Test_ZFilename);

		if (!zfile.good()) 
		{
			cerr << "error opening Genes matrix file " << Test_ZFilename << endl;
			exit(1);
		}


		string s;
		getline(zfile, s);

		stringstream st(s);
		st >> N >> D;
		Z.ReSize(N,D); 

		////////////////added by wei///////
		//getline(zfile, s);

		for (size_t n=1; n<=N; n++) 
		{
			//string geneName;
			//zfile>>geneName;
			for (size_t d=1; d<=D; d++) 
			{
				float val;
				zfile >> val;
				Z(n,d) = val;
			}
		}

		zfile.close();
	}


	Real minsigma=0;

		Real pi = 3.14159265358979323846;


		if (input.size()!=K*M+(M+K)*N+3) 
		{
			cerr << "error input vector size ++++ " <<input.size()<<"  "<<K*M+(M+K)*N+3<< endl;
			exit(1);
		}

		Matrix A(M, K);
		Matrix B(N, M);
		Matrix C(N, K);
//		Matrix mu_A(M,1);
//		Matrix mu_B(N,1);
		Real tau,sigma_2,sigma_1;

		DblVec2Matrix(input, 0, M*K-1, A);
		DblVec2Matrix(input, M*K, M*(K+N)-1, B);
		DblVec2Matrix(input, M*(K+N), K*(M+N)+(M)*N-1, C);
		//DblVec2Matrix(input, M*(K+N), (1+K)*M+M*N-1, mu_A);
//		DblVec2Matrix(input, (K)*M+M*N, (K)*M+(M+1)*N-1, mu_B);

	//	cout<<endl<<"latst tau element: "<<input[(K)*M+(M)*N]<<endl;

		
		tau=minsigma+exp(input[K*(M+N)+(M)*N]);//input[(1+K)*M+(M+1)*N]+mindelta;//
		sigma_1=minsigma+exp(input[K*(M+N)+(M)*N+1]);//input[(1+K)*M+(M+1)*N+1]+mindelta;//
		sigma_2=minsigma+exp(input[K*(M+N)+(M)*N+2]);//input[(1+K)*M+(M+1)*N+1]+mindelta;//

		cout<<"tau: "<<tau<<" "<<"sigma_1: "<<sigma_1<<" sigma_2: "<<sigma_2<<endl;

	//	printMatrix(B); printMatrix(W);printMatrix(mu); cout<<delta<<endl;
		
		
		/*if( logDeterMinant_Sigma_y_inverse.V == 0 )
		{
			cout<<"Matrix Sigma_y_inverse's determinat is 0, there is no inverse of Sigma_y_inverse"<<endl;
			cout<<"sigma_1 is: "<<sigma_1<<" sigma_2 is:"<<sigma_2<<endl;
			cout<<"B is:"<<endl;
			printMatrix2(B);
			exit(1);
		}*/


		Matrix Sigma(N,N);
		Sigma=0;

		IdentityMatrix I_N(N);

		Matrix B_B_t = B*B.t();
		Sigma = sigma_1*sigma_1*B_B_t+tau*tau*Kin + sigma_2*sigma_2*I_N;


		//printMatrix(Sigma);

		//cout<<Sigma.LogDeterminantValue();



		Matrix Sigma_inverse(N,N);
		Sigma_inverse=0;

		Sigma_inverse = Sigma.i();

		//if( Sigma_y_inverse(0,0)==0&&Sigma_y_inverse.Determinant() == 0 )
		//{
		//	cout<<"Matrix Sigma_y_inverse's determinat is 0, there is no inverse of Sigma_y_inverse"<<endl;
		//	cout<<"sigma_1 is: "<<sigma_1<<" sigma_2 is:"<<sigma_2<<endl;
		//	cout<<"B is:"<<endl;
		//	printMatrix3(B);
		//	exit(1);
		//}

		Real f = 0;

		
		Real secondPart = 0;
		Matrix x_avg(K,1);
		x_avg=0;
		Matrix z_avg(N,1);
		z_avg=0;
		for( int d = 1; d<=D; d++)
		{
			x_avg += 1.0/D*X.Column(d);
			z_avg += 1.0/D*Z.Column(d);
		}
		Matrix allOne(1,D);
		allOne=1;
		Matrix T(N,D);
		T=0;
		T=Z-z_avg*allOne-(B*A+C)*(X-x_avg*allOne);


		for( int d = 1; d<=D; d++)
		{
			//Matrix meanPart(N,1);
			//meanPart=0;
			//meanPart=Z.Column(d)-z_avg-B*A*(X.Column(d)-x_avg);
			//T=T|meanPart;
			Matrix temp = (T.Column(d)).t()*Sigma_inverse*(T.Column(d));
			secondPart+=temp(1,1);
			temp.Release();
			//meanPart.Release();
		}

		
		/*Matrix T2(N,1);
		T2=0;*/
		


		//for( int d = 1; d<=D; d++)
		//{
		//	Matrix meanPart(N,1);
		//	meanPart=0;
		//	meanPart=Z.Column(d)-z_avg-B*A*(X.Column(d)-x_avg);
		//	T2=T2|meanPart;
		//	Matrix temp = (meanPart).t()*Sigma_inverse*(meanPart);
		//	secondPart+=temp(1,1);
		//	temp.Release();
		//	meanPart.Release();
		//}

		
//		cout<<Sigma.Determinant()<<endl;

		f=D/2.0*Sigma.LogDeterminantValue()+1/2.0*secondPart;


		A.Release(); B.Release(); x_avg.Release();z_avg.Release();
		Sigma_inverse.Release();
		Sigma.Release();
		I_N.Release();

		return f;

}


void test()
{
	


	///////////////////testing obj////////////////
	Matrix X=Matrix(2,2);
	Matrix Z=Matrix(2,2);

	X(1,1)=1;
	X(1,2)=0;
	X(2,1)=1;
	X(2,2)=1;

	Z(1,1)=0.2;
	Z(1,2)=0.4;
	Z(2,1)=0.3;
	Z(2,2)=0.5;

	int N=2;
	int	M=2;
	int K=2;
	int D=2;

	/////////////////testing obj///////////////
	Matrix A(2,2),B(2,2),mu_A(2,1),mu_B(2,1);

	DblVec testAns(14);
	A(1,1)=0.7;
	A(2,1)=0.3;
	A(1,2)=0.1;
	A(2,2)=0.2;
	B(1,1)=0.5;
	B(2,1)=0.7;
	B(1,2)=0.8;
	B(2,2)=0.9;
	Matrix Kin(2,2);
	Kin=0;
	Kin(1,1)=0.1;
	Kin(2,2)=0.6;
	
	double minsigma =0;
	Real pi = 3.14159265358979323846;

	double tau=minsigma+7.3891;
	double sigma_2=minsigma+7.3891;

	

	//	printMatrix(B); printMatrix(W);printMatrix(mu); cout<<delta<<endl;
		
		
	Matrix Sigma(N,N);
		Sigma=0;

		IdentityMatrix I_N(N);
		Sigma = B*B.t()+tau*tau*Kin + sigma_2*sigma_2*I_N;
		Matrix Sigma_inverse(N,N);
		Sigma_inverse=0;

		Sigma_inverse = Sigma.i();

		//if( Sigma_y_inverse(0,0)==0&&Sigma_y_inverse.Determinant() == 0 )
		//{
		//	cout<<"Matrix Sigma_y_inverse's determinat is 0, there is no inverse of Sigma_y_inverse"<<endl;
		//	cout<<"sigma_1 is: "<<sigma_1<<" sigma_2 is:"<<sigma_2<<endl;
		//	cout<<"B is:"<<endl;
		//	printMatrix3(B);
		//	exit(1);
		//}

		Real f = 0;

		Real secondPart = 0;
		Matrix x_avg(K,1);
		x_avg=0;
		Matrix z_avg(N,1);
		z_avg=0;
		for( int d = 1; d<=D; d++)
		{
			x_avg += 1.0/D*X.Column(d);
			z_avg += 1.0/D*Z.Column(d);
		}
		Matrix T(N,1);
		T=0;
		for( int d = 1; d<=D; d++)
		{
			Matrix meanPart(N,1);
			meanPart=0;
			meanPart=Z.Column(d)-z_avg-B*A*(X.Column(d)-x_avg);
			T=T|meanPart;
			Matrix temp = meanPart.t()*Sigma_inverse*meanPart;
			secondPart+=temp(1,1);
			temp.Release();
			meanPart.Release();
		}

		f=D/2.0*Sigma.LogDeterminantValue()+1/2.0*secondPart;

		cout<<"obj value: "<<f<<endl;

		T=T.SubMatrix(1,N,2,D+1);
		cout<<"  f: "<<f<<endl;

	
		Matrix g1(M,K);
		Matrix g2(N,M);
		Matrix g3(1,1);
		Matrix g4(1,1);

		g1=0;
		g2=0;
		g3=0;
		g4=0;




		for( int d=1; d<=D;d++)
		{
			Matrix x_d = X.Column(d);
			Matrix z_d = Z.Column(d);

			Matrix t_d(K,1);
			t_d=0;
			t_d=T.SubMatrix(1,N,d,d);
			Matrix Sigma_i_t_d = Sigma_inverse*t_d;
			Matrix phi_d = 1/2.0*(Sigma_inverse-Sigma_i_t_d*Sigma_i_t_d.t());
			g1 += -1*(B.t()*Sigma_i_t_d*(x_d-x_avg).t());

			Matrix Xi_1 = -1*Sigma_i_t_d*(x_d-x_avg).t()*A.t();
			Matrix Xi_2(N,M);
			Xi_2=2*phi_d*B;
			/*for( int i=1;i<=N;i++)
				for( int j=1; j<=M; j++)
				{
					Matrix E(N,M);
					E=0;
					E(i,j)=1;
					Matrix E_B_t=E*B.t();
					Xi_2(i,j)=(phi_d*(E_B_t+E_B_t.t())).Trace();
					E.Release();
					E_B_t.Release();
				}*/
			g2+=Xi_1+Xi_2;

			g3+=2*tau*(phi_d*Kin).Trace();

			g4+=2*sigma_2*phi_d.Trace();


			x_d.Release();
			z_d.Release();
			Xi_1.Release();
			Xi_2.Release();
			phi_d.Release();
			t_d.Release();
			Sigma_i_t_d.Release();

		}


		g3=g3*(tau-minsigma);

		g4=g4*(sigma_2-minsigma);

		printMatrix3(g1);
		printMatrix3(g2);
		printMatrix3(g3);
		printMatrix3(g4);
		
}



int main(int argc, char* argv[]) 
{
	//test();

	///////Initialization//////////

	const char* X_file = "X.txt";
	const char* Z_file = "Z.txt";
	const char* Test_X_file = "X.txt";
	const char* Test_Z_file = "Z.txt";
	

/*	const char* X_file = "data/yeast_snps_train.txt";
	const char* Z_file = "data/yeast_gene_train.txt";
	const char* Test_X_file ="data/yeast_snps_test.txt";
	const char* Test_Z_file = "data/yeast_gene_test.txt";
	*/
	
	if(argc != 4 )
	{
		cout<<"Usage: ./main M H lambda"<<endl;
		return 0;

	}

	
	int M=atoi(argv[1]);//10;
	int H=atoi(argv[2]);
	

	TwoLayerLinearRegression *prob = new TwoLayerLinearRegression(X_file, Z_file, M, H);
	int D=prob->NumInstances();
	int K=prob->NumSNPs();
	int N=prob->NumGENs();
	
	
	cout<<"D: "<<D<<"   K: "<<K<<"   N: "<<N<<"   M: "<<M<<"   H: "<<H<<endl;
//	prob->output_matrices();

	DifferentiableFunction *obj;
	obj = new TwoLayerLinearRegressionObjective(*prob);

	int dimension = K*(M+N)+(M)*N+3;

	DblVec init(dimension), ans(dimension);
	initialize_input(init);
	init[dimension-3]=init[dimension-2] = init[dimension-1] = -2;//0.1353;// -2; //-5.9697e+02 ;
	
//	printDblVec(init);

//	cout<<"press any key to start..."<<endl;
//	getchar();

	///////Setting Parameters//////////

	bool quiet = false;
	double tol = 1*(1e-3);//0.9*(1e-4);
	double l2weight = 0;
	int m = 10; 


	///////Iteration Starts//////////

	Matrix A_MAP(M, K);
	Matrix B_MAP(N, M);
	Matrix C_MAP(N, K);
//	Matrix mu_A_ML(M, 1);
//	Matrix mu_B_ML(N, 1);
	float sigma_1_ML;
	float sigma_2_ML;
	float tau;
	vector<double> non_zeros_A_MAP, non_zeros_B_MAP, non_zeros_C_MAP;
	vector<double> func_value_out, func_value_in;
	vector<double> sigma_2_ML_value;
	vector<double> sigma_1_ML_value;
	vector<double> tau_ML_value;

	//vector<double> lambdaVector;

	float  lambda= (float)atof(argv[3]);//3*itt;
	//float gamma = (float)atof(argv[4]);//2*itt;

	//float lambda2 = 0;
	double l1weight = 0;

	for (int itt=1;itt<=1;itt++)
	{
		/////////////////////////init parameter of Laplace distribution////////////////
		
/*
		for( int i =0; i < M*K; i++)
			lambdaVector.push_back(lambda);

		for( int i = 0; i< M*N; i++)
			lambdaVector.push_back(gamma);
			

		for( int i =0; i < M+N+2; i++)
			lambdaVector.push_back(lambda2);

*/
		l1weight=lambda;
		cout<<"*******************"<<endl;
		cout<<"Iteration: "<< itt<<"  Lambda: "<<lambda<<endl;

		OWLQN opt(quiet);
		opt.Minimize(*obj, init, ans, l1weight, tol, m);//, up_start_position);
		
		if (!quiet) cout << "Finished with optimization.  " <<endl;//<< nonZero << "/" << size << " non-zero weights." << endl;

		Matrix Kin = prob->getKin();

		func_value_out.push_back(outsample_test(Test_X_file, Test_Z_file, Kin,M, ans));
		func_value_in.push_back(outsample_test(X_file, Z_file, Kin, M, ans));

		///////////////save values///////////////////////////
		
		DblVec2Matrix(ans, 0, M*K-1, A_MAP);
		DblVec2Matrix(ans, M*K, M*(K+N)-1, B_MAP);
		DblVec2Matrix(ans, M*(K+N), K*(M+N)+(M)*N-1, C_MAP);
		
		double threshold_of_weight =  0.01;

		non_zeros_A_MAP.push_back(((float)matrix_non_zeros(A_MAP, threshold_of_weight))/(float)(M*K));
		

		non_zeros_B_MAP.push_back(((float)matrix_non_zeros(B_MAP,threshold_of_weight))/(float)(N*M));

		non_zeros_C_MAP.push_back(((float)matrix_non_zeros(C_MAP,threshold_of_weight))/(float)(N*K));



		tau = exp(ans[K*(M+N)+(M)*N]);
		sigma_1_ML = exp(ans[K*(M+N)+(M)*N+1]);
		sigma_2_ML = exp(ans[K*(M+N)+(M)*N+2]);
		tau_ML_value.push_back(tau);
		sigma_1_ML_value.push_back(sigma_1_ML);
		sigma_2_ML_value.push_back(sigma_2_ML);

	}


	///////Output Files//////////
	ostringstream ost_M;
	ost_M << M;
	string M_str(ost_M.str());

	ostringstream ost_H;
	ost_H << H;
	string H_str(ost_H.str());

	ostringstream ost_lambda;
	ost_lambda << lambda;
	string lambda_str(ost_lambda.str());

	//ostringstream ost_gamma;
	//ost_gamma << gamma;
	//string gamma_str(ost_gamma.str());

	string nameSuffix("_M(");
	nameSuffix.append(M_str);
	nameSuffix.append(")_H(");
	nameSuffix.append(H_str);
	nameSuffix.append(")_lambda(");
	nameSuffix.append(lambda_str);
	//nameSuffix.append(")_gamma(");
	//nameSuffix.append(gamma_str);
	nameSuffix.append(").txt");

	string funcName_in("func_value_out");
	string funcName_out("func_value_in");
	string tau_value("tau_value");
	string sigma_1_value("sigma_1_value");
	string sigma_2_value("sigma_2_value");
	string non_zeros_A("non_zeros_A_MAP");
	string non_zeros_B("non_zeros_B_MAP");
	string non_zeros_C("non_zeros_C_MAP");
	string A_str("A_MAP");
	string B_str("B_MAP");
	string C_str("C_MAP");
	funcName_in.append(nameSuffix);
	funcName_out.append(nameSuffix);
	sigma_1_value.append(nameSuffix);
	tau_value.append(nameSuffix);
	sigma_2_value.append(nameSuffix);
	non_zeros_A.append(nameSuffix);
	non_zeros_B.append(nameSuffix);
	non_zeros_C.append(nameSuffix);
	A_str.append(nameSuffix);
	B_str.append(nameSuffix);
	C_str.append(nameSuffix);




	printVector(func_value_out, funcName_in.c_str());
	printVector(func_value_in, funcName_out.c_str());
	printVector(tau_ML_value, tau_value.c_str());
	printVector(sigma_1_ML_value, sigma_1_value.c_str());
	printVector(sigma_2_ML_value, sigma_2_value.c_str());
	printVector(non_zeros_A_MAP, non_zeros_A.c_str());
	printVector(non_zeros_B_MAP, non_zeros_B.c_str());
	printVector(non_zeros_C_MAP, non_zeros_C.c_str());

	printMatrix2file(A_MAP, A_str.c_str());
	printMatrix2file(B_MAP, B_str.c_str());
	printMatrix2file(C_MAP, C_str.c_str());


	return 0;
}
