#pragma once

#include <fstream>
#include <string>

#include "OWLQN.h"
#include "newmatap.h"                // need matrix applications

void printDblVec(const DblVec &v);

void printMatrix(const Matrix& A);

void DblVec2Matrix(const DblVec& vec, const int k1, const int k2, Matrix& A);


class LinearRegPPCAProblem
{
	Matrix R;
	Matrix X;
	size_t N,K,D;

	friend struct LinearRegPPCAObjective;

public:
	LinearRegPPCAProblem(size_t N, size_t K, size_t D) : R(N,K), X(N,D), N(N), K(K), D(D) { }

	LinearRegPPCAProblem(const char* Rfile, const char* XFile);

	size_t NumInstances() const { return N; }	
	size_t NumRegulators() const { return K; }
	size_t NumNonRegulators() const { return D; }

	double output_matrices();

	
};


struct LinearRegPPCAObjective : public DifferentiableFunction 
{
	const LinearRegPPCAProblem& problem;
	const int M; // number of hidden variables

	LinearRegPPCAObjective(const LinearRegPPCAProblem& p, int M = 0) : problem(p), M(M) { }

	double Eval(const DblVec& input, DblVec& gradient);

};


