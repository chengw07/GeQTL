#include "TwoLayerLinearRegression.h"
#include <iostream>
#include <fstream>
#include <string>
#include <math.h>


using namespace std;

void printMatrix2(Matrix& matrix)
{
	for( int i=1; i<=matrix.Nrows();i++)
	{
		for( int j=1;j<=matrix.Ncols();j++)
		{
			cout<<matrix(i,j)<<" ";
		}
		cout<<endl;
	}


}


void printDblVec(const DblVec &v)
{
	for (int i=0;i<v.size();i++)
	{
		cout<<" "<<v[i]<<" ";
	}
	cout<<endl;
}

void printMatrix(const Matrix &A)
{
	size_t m = A.Nrows();
	size_t n = A.Ncols();

//	cout<<"#rows: "<<m<<", #cols: "<<n<<endl;

	for (int i=1;i<=m;i++)
	{
		for (int j=1;j<=n;j++)
		{
			cout<<" "<<A(i,j)<<" ";
		}
		cout<<endl;
	}
	
	cout<<endl;
}



void DblVec2Matrix(const DblVec& vec, const int k1, const int k2, Matrix& A)
{
	//vec should be treated as a column vector
	//k1: start from 0, k2: ending position
	if ((k2>vec.size())||(k2-k1+1)!=(A.Nrows()*A.Ncols())) 
	{
		cerr<<"error in Vector2Matrix!";
		exit(1);
	}

	int k=k1;

	for(int j = 1; j <= A.Ncols(); j++ ) 
	{
		for (int i=1;i<=A.Nrows();i++)
		{
			A(i,j) = vec[k];
			k++;
		}
	}
}


TwoLayerLinearRegression::TwoLayerLinearRegression(const char* XFilename, const char* ZFilename, int M)
{
	this->M = M;
	{
		ifstream xfile(XFilename);

		if (!xfile.good()) 
		{
			cerr << "error opening X matrix file " << XFilename << endl;
			exit(1);
		}


		string s;
		getline(xfile, s);

		stringstream st(s);
		st >> K >> D;
		X.ReSize(K,D); 

		////////////////added by wei///////
		//getline(xfile, s);

		for (size_t k=1; k<=K; k++) 
		{
			//string geneName;
			//xfile>>geneName;
			for (size_t d=1; d<=D; d++) 
			{
				float val;
				xfile >> val;
				X(k,d) = val;
			}
		}

		xfile.close();
	}


	{
		ifstream zfile(ZFilename);

		if (!zfile.good()) 
		{
			cerr << "error opening Z matrix file " << ZFilename << endl;
			exit(1);
		}


		string s;
		getline(zfile, s);

		stringstream st(s);
		st >> N >> D;
		Z.ReSize(N,D); 

		////////////////added by wei///////
		//getline(zfile, s);

		for (size_t n=1; n<=N; n++) 
		{
			//string geneName;
			//zfile>>geneName;
			for (size_t d=1; d<=D; d++) 
			{
				float val;
				zfile >> val;
				Z(n,d) = val;
			}
		}

		zfile.close();
	}




}

double TwoLayerLinearRegression::output_matrices()
{
	printMatrix(X);
	printMatrix(Z);

	return 0;
}



double TwoLayerLinearRegressionObjective::Eval(const DblVec& input, DblVec& gradient)
{

	    Real minsigma=1e-5;

		Real pi = 3.14159265358979323846;

		int N=problem.N;
		int K=problem.K;
		int D=problem.D;
		int M=problem.M;

		if (input.size()!=(1+K)*M+(M+1)*N+2) 
		{
			cerr << "error input vector size " << endl;
			exit(1);
		}

		
		Matrix A(M, K);
		Matrix B(N, M);
		Matrix mu_A(M,1);
		Matrix mu_B(N,1);
		Real sigma_1,sigma_2;

		DblVec2Matrix(input, 0, M*K-1, A);
		DblVec2Matrix(input, M*K, M*(K+N)-1, B);
		DblVec2Matrix(input, M*(K+N), (1+K)*M+M*N-1, mu_A);
		DblVec2Matrix(input, (1+K)*M+M*N, (1+K)*M+(M+1)*N-1, mu_B);

		cout<<endl<<"latst element: "<<input[(1+K)*M+(M+1)*N]<<endl;

		//sigma_1=minsigma+exp(input[(1+K)*M+(M+1)*N]);
		sigma_1=input[(1+K)*M+(M+1)*N];//
		//sigma_2=minsigma+exp(input[(1+K)*M+(M+1)*N+1]);
		sigma_2=input[(1+K)*M+(M+1)*N+1];//

		cout<<"sigma_1: "<<sigma_1<<" "<<"sigma_2: "<<sigma_2<<endl;

	//	printMatrix(B); printMatrix(W);printMatrix(mu); cout<<delta<<endl;
		
		IdentityMatrix I_M(M);
		Matrix Sigma_y_inverse = 1/pow(sigma_1,2)*I_M+1/pow(sigma_2,2)*(B.t())*B;


		/*if( logDeterMinant_Sigma_y_inverse.V == 0 )
		{
			cout<<"Matrix Sigma_y_inverse's determinat is 0, there is no inverse of Sigma_y_inverse"<<endl;
			cout<<"sigma_1 is: "<<sigma_1<<" sigma_2 is:"<<sigma_2<<endl;
			cout<<"B is:"<<endl;
			printMatrix2(B);
			exit(1);
		}*/

		Matrix Sigma_y = Sigma_y_inverse.i();

		double firstPart = D*N/2.0*log(2*pi)+D*M*log(sigma_1)+D*N*log(sigma_2)+D/2.0*Sigma_y_inverse.LogDeterminantValue();//log(Sigma_y_inverse.Determinant());

		Matrix A_t_A = A.t()*A;

		Matrix mu_A_t_A = mu_A.t()*A;

		Matrix mu_A_t_mu_A_M = (mu_A.t())*mu_A;

		double mu_A_t_mu_A = mu_A_t_mu_A_M(1,1);

		Matrix mu_B_t_mu_B_M = (mu_B.t())*mu_B;

		double mu_B_t_mu_B = mu_B_t_mu_B_M(1,1);

		Matrix mu_B_t_B = mu_B.t()*B;

		Matrix B_t_mu_B = mu_B_t_B.t();

		Real f = 0;

		Real secondPart = 0;

		Matrix X = problem.X;
		Matrix Z = problem.Z;

		for( int d = 1; d<=D; d++)
		{
			Matrix x_d = X.Column(d);
			Matrix z_d = Z.Column(d);
			Matrix temp = 1/pow(sigma_1,2)*(x_d.t()*A_t_A*x_d+2*mu_A_t_A*x_d+mu_A_t_mu_A)+1/pow(sigma_2,2)*(z_d.t()*z_d-2*mu_B.t()*z_d+mu_B_t_mu_B)-(1/pow(sigma_1,2)*(x_d.t()*A.t()+mu_A.t())+1/pow(sigma_2,2)*(z_d.t()*B-mu_B_t_B))*Sigma_y*(1/pow(sigma_1,2)*(A*x_d+mu_A)+1/pow(sigma_2,2)*(B.t()*z_d-B_t_mu_B));

			secondPart = secondPart +temp(1,1);

		}

		secondPart = 1.0/2.0*secondPart;


		f = firstPart+secondPart;



		cout<<"  f: "<<f;

		Matrix g1(M,K);
		Matrix g2(N,M);
		Matrix g3(M,1);
		Matrix g4(N,1);
		Matrix g5(1,1);
		Matrix g6(1,1);

		g1=0;
		g2=0;
		g3=0;
		g4=0;
		g5=0;
		g6=0;


		Matrix x_d_x_d_t_sum(K,K);
		Matrix z_d_x_d_t_sum(N,K);
		Matrix x_d_t_sum(1,K);
		Matrix z_d_z_d_t_sum(N,N);
		Matrix z_d_sum(N,1);

		x_d_x_d_t_sum=0;
		z_d_x_d_t_sum=0;
		x_d_t_sum=0;
		z_d_z_d_t_sum=0;
		z_d_sum=0;

		for( int d =1; d<=D; d++)
		{
			Matrix x_d = X.Column(d);
			Matrix z_d = Z.Column(d);

			x_d_x_d_t_sum += x_d*x_d.t();

			z_d_x_d_t_sum += z_d*x_d.t();

			x_d_t_sum += x_d.t();

			z_d_z_d_t_sum += z_d*z_d.t();

			z_d_sum += z_d;

			x_d.Release();
			z_d.Release();

		}
		Matrix Sigma_y_B_t = Sigma_y*B.t();
		Matrix Sigma_y_A = Sigma_y*A;
		Matrix Sigma_y_mu_A = Sigma_y*mu_A;
		g1= 1/pow(sigma_1,2)*A*x_d_x_d_t_sum-1/pow(sigma_1,4)*Sigma_y_A*x_d_x_d_t_sum-1/(pow(sigma_1,2)*pow(sigma_2,2))*Sigma_y_B_t*z_d_x_d_t_sum+1/pow(sigma_1,2)*mu_A*x_d_t_sum-1/pow(sigma_1,4)*Sigma_y_mu_A*x_d_t_sum+1/(pow(sigma_1,2)*pow(sigma_2,2))*Sigma_y_B_t*mu_B*x_d_t_sum;


		IdentityMatrix I_N(N);

		Matrix temp2 = Sigma_y*(A*z_d_x_d_t_sum.t()- A*x_d_t_sum.t()*mu_B.t()+mu_A*z_d_sum.t()-D*mu_A*mu_B.t());

		Matrix part2 = B*temp2*Sigma_y_B_t.t()+B*Sigma_y_B_t*temp2.t()-pow(sigma_2,2)*temp2.t();

		Matrix part3 = Sigma_y_B_t.t()*(A*x_d_x_d_t_sum*A.t()+A*x_d_t_sum.t()*mu_A.t()+mu_A*x_d_t_sum*A.t()+D*mu_A*mu_A.t())*Sigma_y;

		g2 = D/pow(sigma_2,2)*B*Sigma_y+1/pow(sigma_2,4)*(1/pow(sigma_2,2)*B*Sigma_y_B_t-I_N)*(z_d_z_d_t_sum-z_d_sum*mu_B.t()-mu_B*z_d_sum.t()+D*mu_B*mu_B.t())*Sigma_y_B_t.t()+1/(pow(sigma_1,2)*pow(sigma_2,4))*(part2)+1/(pow(sigma_1,4)*pow(sigma_2,2))*(part3);

		g3 = 1.0/2.0*(2/pow(sigma_1,2)*(A*x_d_t_sum.t()+D*mu_A)-2/pow(sigma_1,4)*Sigma_y*(D*mu_A+A*x_d_t_sum.t())-2/(pow(sigma_1,2)*pow(sigma_2,2))*Sigma_y*(B.t()*z_d_sum-D*B.t()*mu_B));

		g4 = 1.0/2.0*(2/pow(sigma_1,2)*(-1*z_d_sum+D*mu_B)+2/pow(sigma_1,4)*B*Sigma_y_B_t*(z_d_sum-D*mu_B)+2/(pow(sigma_1,2)*pow(sigma_2,2))*Sigma_y_B_t.t()*(A*x_d_t_sum.t()+D*mu_A));


		g5(1,1) += D*M/sigma_1-D*Sigma_y.Trace()/pow(sigma_1,3);

		for( int d=1; d<=D;d++)
		{
			Matrix x_d = X.Column(d);
			Matrix z_d = Z.Column(d);

			Matrix part1=-1/pow(sigma_1,3)*(x_d.t()*A.t()*A*x_d+2*mu_A.t()*A*x_d+mu_A.t()*mu_A);

			Matrix temp2=A*x_d+mu_A;
			Matrix temp1=temp2.t()*Sigma_y;
			
			Matrix temp3=B.t()*z_d-B.t()*mu_B;
			Matrix temp4=temp3.t()*Sigma_y;

			g5 += part1+2/pow(sigma_1,5)*temp1*temp2-1/pow(sigma_1,7)*temp1*temp1.t()+2/(pow(sigma_1,3)*pow(sigma_2,2))*temp1*temp3-2/(pow(sigma_1,5)*pow(sigma_2,2))*temp1*temp4.t()-1/(pow(sigma_1,3)*pow(sigma_2,4))*temp4*temp4.t();

			x_d.Release();
			z_d.Release();
			part1.Release();
			temp1.Release();
			temp2.Release();
			temp3.Release();
			temp4.Release();

		}

		g6(1,1) += D*N/sigma_2-D*(Sigma_y_B_t*B).Trace()/pow(sigma_2,3);

		for( int d=1; d<=D;d++)
		{
			Matrix x_d = X.Column(d);
			Matrix z_d = Z.Column(d);

			Matrix part1=-1.0/pow(sigma_2,3)*(z_d.t()*z_d-2*mu_B.t()*z_d+mu_B.t()*mu_B);

			Matrix temp2=(z_d.t()*B-mu_B.t()*B).t();
			Matrix temp1=temp2.t()*Sigma_y;
			Matrix temp3 = temp1*B.t();

			Matrix temp4=(x_d.t()*A.t()+mu_A.t())*Sigma_y;
			Matrix temp5 = temp4*B.t();


			g6 += part1+2/pow(sigma_2,5)*temp1*temp2-1/pow(sigma_2,7)*temp3*temp3.t()+2/(pow(sigma_1,2)*pow(sigma_2,3))*temp2.t()*temp4.t()-2/(pow(sigma_1,2)*pow(sigma_2,5))*temp3*temp5.t()-1/(pow(sigma_1,4)*pow(sigma_2,3))*temp5*temp5.t();

			x_d.Release();
			z_d.Release();
			part1.Release();
			temp1.Release();
			temp2.Release();
			temp3.Release();
			temp4.Release();
			temp5.Release();


		}

		//g5=g5*(sigma_1-minsigma);

	//	g6=g6*(sigma_2-minsigma);


	//	printMatrix(g1);	printMatrix(g2);	printMatrix(g3); cout<<g4<<endl;


		int k=0;

		{for (int j=1;j<=g1.Ncols();j++)
		{
			for (int i=1;i<=g1.Nrows();i++)
			{
				gradient[k] = g1(i,j);
				k++;
			}
		}}

		{for (int j=1;j<=g2.Ncols();j++)
		{
			for (int i=1;i<=g2.Nrows();i++)
			{
				gradient[k] = g2(i,j);
				k++;
			}
		}}

		{for (int j=1;j<=g3.Ncols();j++)
		{
			for (int i=1;i<=g3.Nrows();i++)
			{
				gradient[k] = g3(i,j);
				k++;
			}
		}}
		{for (int j=1;j<=g4.Ncols();j++)
		{
			for (int i=1;i<=g4.Nrows();i++)
			{
				gradient[k] = g4(i,j);
				k++;
			}
		}}

		gradient[k] = g5(1,1);
		gradient[k+1] = g6(1,1);

	//	printDblVec(gradient);

		A.Release(); B.Release(); mu_A.Release(); mu_B.Release(); I_M.Release(); I_N.Release(); 
		g1.Release(); g2.Release(); g3.Release();g4.Release(); g5.Release(); g6.Release(); temp2.Release();part2.Release();part3.Release();
		Sigma_y_B_t.Release();
		Sigma_y_A.Release();
		Sigma_y_mu_A.Release();
		x_d_x_d_t_sum.Release();
		z_d_x_d_t_sum.Release();
		x_d_t_sum.Release();
		z_d_z_d_t_sum.Release();
		z_d_sum.Release();


		Sigma_y_inverse.Release();

		Sigma_y.Release();

		A_t_A.Release();

		mu_A_t_A.Release();

		mu_A_t_mu_A_M.Release();

		mu_B_t_mu_B_M.Release();


		mu_B_t_B.Release();

		B_t_mu_B.Release();

		/*cout<<endl;
		cout<<"g1:"<<endl;
		printMatrix(g1);
		cout<<"g2:"<<endl;
		printMatrix(g2);
		cout<<"g3:"<<endl;
		printMatrix(g3);
		cout<<"g4:"<<endl;
		printMatrix(g4);
		cout<<"g5:"<<endl;
		printMatrix(g5);
		cout<<"g6:"<<endl;
		printMatrix(g6);

		cout<<"f:"<<f<<endl;

		cout<<"WeightMatrix"<<endl;
		for( int i = 0; i<input.size();i++)
		{
			cout<<input[i]<<" ";
		}
		cout<<endl;*/


		return f;




}

