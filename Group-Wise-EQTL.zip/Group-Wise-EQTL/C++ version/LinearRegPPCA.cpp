#include "LinearRegPPCA.h"
#include <iostream>
#include <fstream>
#include <string>
#include <math.h>


using namespace std;


void printDblVec(const DblVec &v)
{
	for (int i=0;i<v.size();i++)
	{
		cout<<" "<<v[i]<<" ";
	}
	cout<<endl;
}

void printMatrix(const Matrix &A)
{
	size_t m = A.Nrows();
	size_t n = A.Ncols();

	cout<<"#rows: "<<m<<", #cols: "<<n<<endl;

	for (int i=1;i<=m;i++)
	{
		for (int j=1;j<=n;j++)
		{
			cout<<" "<<A(i,j)<<" ";
		}
		cout<<endl;
		getchar();
	}
	
	cout<<endl;
}



void DblVec2Matrix(const DblVec& vec, const int k1, const int k2, Matrix& A)
{
	//vec should be treated as a column vector
	//k1: start from 0, k2: ending position
	if ((k2>vec.size())||(k2-k1+1)!=(A.Nrows()*A.Ncols())) 
	{
		cerr<<"error in Vector2Matrix!";
		exit(1);
	}

	int k=k1;

	for(int j = 1; j <= A.Ncols(); j++ ) 
	{
		for (int i=1;i<=A.Nrows();i++)
		{
			A(i,j) = vec[k];
			k++;
		}
	}
}


LinearRegPPCAProblem::LinearRegPPCAProblem(const char* RFilename, const char* XFilename)
{

	{
		ifstream rfile(RFilename);

		if (!rfile.good()) 
		{
			cerr << "error opening Regulator matrix file " << RFilename << endl;
			exit(1);
		}


		string s;
		getline(rfile, s);

		stringstream st(s);
		st >> N >> K;
		R.ReSize(N,K); 

		for (size_t n=1; n<=N; n++) 
		{
			for (size_t k=1; k<=K; k++) 
			{
				float val;
				rfile >> val;
				R(n,k) = val;
			}
		}

		rfile.close();
	}


	{
		ifstream xfile(XFilename);

		if (!xfile.good()) 
		{
			cerr << "error opening Non_Regulator matrix file " << XFilename << endl;
			exit(1);
		}


		string s;
		getline(xfile, s);

		stringstream st(s);
		st >> N >> D;
		X.ReSize(N,D); 

		for (size_t n=1; n<=N; n++) 
		{
			for (size_t d=1; d<=D; d++) 
			{
				float val;
				xfile >> val;
				X(n,d) = val;
			}
		}

		xfile.close();
	}




}

double LinearRegPPCAProblem::output_matrices()
{
	printMatrix(R);
	printMatrix(X);

	return 0;
}



double LinearRegPPCAObjective::Eval(const DblVec& input, DblVec& gradient)
{

	Real mindelta=1e-5;
	
	
	if (M==0) 
	{
		Real pi = 3.14159265358979323846;

		int N=problem.N;
		int K=problem.K;
		int D=problem.D;

		if (input.size()!=(D*(K+1)+1)) 
		{
			cerr << "error input vector size " << endl;
			exit(1);
		}

		Matrix B(D, K);
		Matrix mu(D,1);
		Real delta;

		DblVec2Matrix(input, 0, D*K-1, B);
		DblVec2Matrix(input, D*K, D*(K+1)-1, mu);

		cout<<endl<<"last_ele: "<<input[D*(K+1)];

		delta=mindelta+exp(input[D*(K+1)]);

		cout<<"  delta: "<<delta;

//		printMatrix(B); printMatrix(mu); cout<<delta<<endl;
		
		Real log_C_det = 2*D*log(delta);

		cout<<" log_C_det: "<<log_C_det;

		Matrix temp(N,D);
		{for (int i=1;i<=N;i++)
		{
			temp.Row(i)<<mu.t();
		}}

		Matrix X_mmuu_t = (problem.X - problem.R*(B.t()) - temp).t();


		Matrix C_inverse_X_mmuu = X_mmuu_t*pow(delta,-2);

		Real f = -(-(N*D*log(2*pi))/2 - (N*log_C_det)/2 - SP(C_inverse_X_mmuu,X_mmuu_t).Sum()/2); 

		cout<<"  f: "<<f;

		Matrix g1 = C_inverse_X_mmuu*problem.R; 

		Matrix g3(D,1);

		{for(int j=1;j<=D;j++)
		{
			g3(j,1)=C_inverse_X_mmuu.Row(j).Sum();
		}}

		Real g4 = -N*D*pow(delta,-1) + delta*SP(C_inverse_X_mmuu,C_inverse_X_mmuu).Sum(); 	

		g4=g4*(delta-mindelta);

		
	//	printMatrix(g1);	printMatrix(g2);	printMatrix(g3); cout<<g4<<endl;


		int k=0;

		{for (int j=1;j<=g1.Ncols();j++)
		{
			for (int i=1;i<=g1.Nrows();i++)
			{
				gradient[k] = -g1(i,j);
				k++;
			}
		}}


		{for (int j=1;j<=g3.Ncols();j++)
		{
			for (int i=1;i<=g3.Nrows();i++)
			{
				gradient[k] = -g3(i,j);
				k++;
			}
		}}

		gradient[k] = -g4;

	//	printDblVec(gradient);

		temp.Release(); B.Release(); mu.Release();  
		X_mmuu_t.Release(); C_inverse_X_mmuu.Release(); 
		g1.Release(); g3.Release();


		return f;
	}

	else //M!=0
	{
		Real pi = 3.14159265358979323846;

		int N=problem.N;
		int K=problem.K;
		int D=problem.D;

		if (input.size()!=(D*(K+M+1)+1)) 
		{
			cerr << "error input vector size " << endl;
			exit(1);
		}

		Matrix B(D, K);
		Matrix W(D, M);
		Matrix mu(D,1);
		Real delta;

		DblVec2Matrix(input, 0, D*K-1, B);
		DblVec2Matrix(input, D*K, D*(K+M)-1, W);
		DblVec2Matrix(input, D*(K+M), D*(K+M+1)-1, mu);

		cout<<endl<<"last_ele: "<<input[D*(K+M+1)];

		delta=mindelta+exp(input[D*(K+M+1)]);

		cout<<"  delta: "<<delta;

		cout<<"  delta^(-2): "<<pow(delta,-2);	
		
//		printMatrix(B); printMatrix(W);printMatrix(mu); cout<<delta<<endl;
		
		Matrix W_t_W = W.t()*W;

		DiagonalMatrix I(M);
		I=1;
		

		cout<<"  log(delta): "<<log(delta);
	
//		cout<<"  ((I + W_t_W*pow(delta,-2)).Determinant()): "<<((I + W_t_W*pow(delta,-2)).Determinant());
		cout<<"  ((I*pow(delta,2) + W_t_W).Determinant()): "<<((I*pow(delta,2) + W_t_W).Determinant());

		
		Real log_C_det;

		if ((I*pow(delta,2) + W_t_W).Determinant()==0) 
		{
			cout<<" ==0 ";
			log_C_det= 2*D*log(delta)  +  log((I + W_t_W*pow(delta,-2)).Determinant());
			
		}
		else
		{
			log_C_det = 2*D*log(delta)  - 2*M*log(delta) +  log((I*pow(delta,2) + W_t_W).Determinant());

		}



//		Real log_C_det = 2*D*log(delta)  - 2*M*log(delta) +  log((I*pow(delta,2) + W_t_W).Determinant());


		cout<<"  log_C_det: "<<log_C_det;

		Matrix Mx = W_t_W + pow(delta,2)*I;

		Matrix Mx_inv_W_t = (Mx.i())*(W.t());

		Matrix temp(N,D);
		{for (int i=1;i<=N;i++)
		{
			temp.Row(i)<<mu.t();
		}}

		Matrix X_mmuu_t = (problem.X - problem.R*(B.t()) - temp).t();

		Matrix C_inverse_X_mmuu = (X_mmuu_t - W*(Mx_inv_W_t*X_mmuu_t))*pow(delta,-2);

		Real f = -(-(N*D*log(2*pi))/2 - (N*log_C_det)/2 - SP(C_inverse_X_mmuu,X_mmuu_t).Sum()/2); 

		cout<<"  f: "<<f;

		Matrix g1 = C_inverse_X_mmuu*problem.R; 

		Matrix g2 = C_inverse_X_mmuu*(C_inverse_X_mmuu.t()*W) - N*(W-W*(Mx_inv_W_t*W))*pow(delta,-2);


		Matrix g3(D,1);

		{for(int j=1;j<=D;j++)
		{
			g3(j,1)=C_inverse_X_mmuu.Row(j).Sum();
		}}

		Real g4 = -N*(D-(Mx_inv_W_t*W).Trace())*pow(delta,-1) + delta*SP(C_inverse_X_mmuu,C_inverse_X_mmuu).Sum(); 	

		g4=g4*(delta-mindelta);


	//	printMatrix(g1);	printMatrix(g2);	printMatrix(g3); cout<<g4<<endl;


		int k=0;

		{for (int j=1;j<=g1.Ncols();j++)
		{
			for (int i=1;i<=g1.Nrows();i++)
			{
				gradient[k] = -g1(i,j);
				k++;
			}
		}}

		{for (int j=1;j<=g2.Ncols();j++)
		{
			for (int i=1;i<=g2.Nrows();i++)
			{
				gradient[k] = -g2(i,j);
				k++;
			}
		}}

		{for (int j=1;j<=g3.Ncols();j++)
		{
			for (int i=1;i<=g3.Nrows();i++)
			{
				gradient[k] = -g3(i,j);
				k++;
			}
		}}

		gradient[k] = -g4;

	//	printDblVec(gradient);

		temp.Release(); B.Release(); W.Release(); mu.Release(); I.Release(); W_t_W.Release(); 
		Mx.Release(); Mx_inv_W_t.Release(); X_mmuu_t.Release(); C_inverse_X_mmuu.Release(); 
		g1.Release(); g2.Release(); g3.Release();

		return f;


	}

}

