#include "TwoLayerLinearRegression.h"
#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <ctime>

using namespace std;

void printMatrix2(Matrix& matrix)
{
	for( int i=1; i<=matrix.Nrows();i++)
	{
		for( int j=1;j<=matrix.Ncols();j++)
		{
			cout<<matrix(i,j)<<" ";
		}
		cout<<endl;
	}


}


void printDblVec(const DblVec &v)
{
	for (int i=0;i<v.size();i++)
	{
		cout<<" "<<v[i]<<" ";
	}
	cout<<endl;
}

void printMatrix(const Matrix &A)
{
	size_t m = A.Nrows();
	size_t n = A.Ncols();

	cout<<"#rows: "<<m<<", #cols: "<<n<<endl;

	for (int i=1;i<=m;i++)
	{
		for (int j=1;j<=n;j++)
		{
			cout<<" "<<A(i,j)<<" ";
		}
		cout<<endl;
		getchar();
	}
	
	cout<<endl;
}



void DblVec2Matrix(const DblVec& vec, const int k1, const int k2, Matrix& A)
{
	//vec should be treated as a column vector
	//k1: start from 0, k2: ending position
	if ((k2>vec.size())||(k2-k1+1)!=(A.Nrows()*A.Ncols())) 
	{
		cerr<<"error in Vector2Matrix!";
		exit(1);
	}

	int k=k1;

	for(int j = 1; j <= A.Ncols(); j++ ) 
	{
		for (int i=1;i<=A.Nrows();i++)
		{
			A(i,j) = vec[k];
			k++;
		}
	}
}

void TwoLayerLinearRegression::randomMatrix(Matrix &matrix)
{
	srand((unsigned)time(0));  
	float random_num;     
	float lowest=0, highest=1;     
	float range=(highest-lowest);    
	matrix=0;
	for(int i=1; i<=matrix.Nrows(); i++)
	{        
		for( int j =1; j<= matrix.Ncols();j++)
		{
			random_num = rand()/(RAND_MAX + 1.0);        
			matrix(i,j)=random_num;
		}
	} 

}

TwoLayerLinearRegression::TwoLayerLinearRegression(const char* XFilename, const char* ZFilename, int M,int H)
{
	this->M = M;
	this->H = H;
	{
		ifstream xfile(XFilename);

		if (!xfile.good()) 
		{
			cerr << "error opening X matrix file " << XFilename << endl;
			exit(1);
		}


		string s;
		getline(xfile, s);

		stringstream st(s);
		st >> K >> D;
		X.ReSize(K,D); 

		////////////////added by wei///////
		//getline(xfile, s);

		for (size_t k=1; k<=K; k++) 
		{
			//string geneName;
			//xfile>>geneName;
			for (size_t d=1; d<=D; d++) 
			{
				float val;
				xfile >> val;
				X(k,d) = val;
			}
		}

		xfile.close();
	}


	{
		ifstream zfile(ZFilename);

		if (!zfile.good()) 
		{
			cerr << "error opening Z matrix file " << ZFilename << endl;
			exit(1);
		}


		string s;
		getline(zfile, s);

		stringstream st(s);
		st >> N >> D;
		Z.ReSize(N,D); 

		////////////////added by wei///////
		//getline(zfile, s);

		for (size_t n=1; n<=N; n++) 
		{
			//string geneName;
			//zfile>>geneName;
			for (size_t d=1; d<=D; d++) 
			{
				float val;
				zfile >> val;
				Z(n,d) = val;
			}
		}

		zfile.close();
	}


	Matrix Kin(N,N);
	Kin=calculateKin(Z);
	this->Kin = Kin;

}

double TwoLayerLinearRegression::output_matrices()
{
	printMatrix(X);
	printMatrix(Z);

	return 0;
}
/////////////////////////////////////////////////
Matrix TwoLayerLinearRegression::calculateKin(Matrix Z)
{
	Matrix Z_t = Z.t();

	Matrix result(1,Z_t.Ncols());
	result=0;
	for(int i=1; i<= Z_t.Ncols(); i++)
		for( int j=1; j<=Z_t.Nrows();j++)
			result(1,i)+=Z_t(j,i);
	result/=Z_t.Nrows();
	Matrix Z_t_avg = result;
	result.Release();
	Matrix onesZ(Z_t.Nrows(),1);
	onesZ=1;
	
	Matrix Z_return=Z_t-onesZ*Z_t_avg;

	return Z_return.t()*Z_return/(double)(Z.Ncols()-1.0);

}




double TwoLayerLinearRegressionObjective::Eval(const DblVec& input, DblVec& gradient)
{

	    Real minsigma=1e-5;
	
	

		Real pi = 3.14159265358979323846;

		int N=problem.N;
		int K=problem.K;
		int D=problem.D;
		int M=problem.M;
		int H=problem.H;
		Matrix X = problem.X;
		Matrix Z = problem.Z;

		Matrix Kin = problem.Kin;

		if (input.size()!=K*(M+N)+(M)*N+3) 
		{
			cerr << "error input vector size " << endl;
			exit(1);
		}

		
		Matrix A(M, K);
		Matrix B(N, M);
		Matrix C(N, K);
//		Matrix mu_A(M,1);
//		Matrix mu_B(N,1);
		Real tau,sigma_2,sigma_1;

		DblVec2Matrix(input, 0, M*K-1, A);
		DblVec2Matrix(input, M*K, M*(K+N)-1, B);
		DblVec2Matrix(input, M*(K+N), K*(M+N)+(M)*N-1, C);
		//DblVec2Matrix(input, M*(K+N), (1+K)*M+M*N-1, mu_A);
//		DblVec2Matrix(input, (K)*M+M*N, (K)*M+(M+1)*N-1, mu_B);

		cout<<endl<<"latst tau element: "<<input[(K)*M+(M)*N]<<endl;

		
		tau=minsigma+exp(input[K*(M+N)+(M)*N]);//input[(1+K)*M+(M+1)*N]+mindelta;//
		sigma_1=minsigma+exp(input[K*(M+N)+(M)*N+1]);//input[(1+K)*M+(M+1)*N+1]+mindelta;//
		sigma_2=minsigma+exp(input[K*(M+N)+(M)*N+2]);//input[(1+K)*M+(M+1)*N+1]+mindelta;//

		cout<<"tau: "<<tau<<" "<<"sigma_1: "<<sigma_1<<" sigma_2: "<<sigma_2<<endl;

	//	printMatrix(B); printMatrix(W);printMatrix(mu); cout<<delta<<endl;
		
		
		/*if( logDeterMinant_Sigma_y_inverse.V == 0 )
		{
			cout<<"Matrix Sigma_y_inverse's determinat is 0, there is no inverse of Sigma_y_inverse"<<endl;
			cout<<"sigma_1 is: "<<sigma_1<<" sigma_2 is:"<<sigma_2<<endl;
			cout<<"B is:"<<endl;
			printMatrix2(B);
			exit(1);
		}*/


		Matrix Sigma(N,N);
		Sigma=0;

		IdentityMatrix I_N(N);

		Matrix B_B_t = B*B.t();
		Sigma = sigma_1*sigma_1*B_B_t+tau*tau*Kin + sigma_2*sigma_2*I_N;


		//printMatrix(Sigma);

		//cout<<Sigma.LogDeterminantValue();



		Matrix Sigma_inverse(N,N);
		Sigma_inverse=0;

		Sigma_inverse = Sigma.i();

		//if( Sigma_y_inverse(0,0)==0&&Sigma_y_inverse.Determinant() == 0 )
		//{
		//	cout<<"Matrix Sigma_y_inverse's determinat is 0, there is no inverse of Sigma_y_inverse"<<endl;
		//	cout<<"sigma_1 is: "<<sigma_1<<" sigma_2 is:"<<sigma_2<<endl;
		//	cout<<"B is:"<<endl;
		//	printMatrix3(B);
		//	exit(1);
		//}

		Real f = 0;

		
		Real secondPart = 0;
		Matrix x_avg(K,1);
		x_avg=0;
		Matrix z_avg(N,1);
		z_avg=0;
		for( int d = 1; d<=D; d++)
		{
			x_avg += 1.0/D*X.Column(d);
			z_avg += 1.0/D*Z.Column(d);
		}
		Matrix allOne(1,D);
		allOne=1;
		Matrix T(N,D);
		T=0;
		T=Z-z_avg*allOne-(B*A+C)*(X-x_avg*allOne);


		for( int d = 1; d<=D; d++)
		{
			//Matrix meanPart(N,1);
			//meanPart=0;
			//meanPart=Z.Column(d)-z_avg-B*A*(X.Column(d)-x_avg);
			//T=T|meanPart;
			Matrix temp = (T.Column(d)).t()*Sigma_inverse*(T.Column(d));
			secondPart+=temp(1,1);
			temp.Release();
			//meanPart.Release();
		}

		
		/*Matrix T2(N,1);
		T2=0;*/
		


		//for( int d = 1; d<=D; d++)
		//{
		//	Matrix meanPart(N,1);
		//	meanPart=0;
		//	meanPart=Z.Column(d)-z_avg-B*A*(X.Column(d)-x_avg);
		//	T2=T2|meanPart;
		//	Matrix temp = (meanPart).t()*Sigma_inverse*(meanPart);
		//	secondPart+=temp(1,1);
		//	temp.Release();
		//	meanPart.Release();
		//}

		
//		cout<<Sigma.Determinant()<<endl;

		f=D/2.0*Sigma.LogDeterminantValue()+1/2.0*secondPart;

		cout<<"obj value: "<<f<<endl;

		
		//cout<<"  f: "<<f;

	
		Matrix g1(M,K);
		Matrix g2(N,M);
		Matrix g3(N,K);
		Matrix g4(1,1);
		Matrix g5(1,1);
		Matrix g6(1,1);

		g1=0;
		g2=0;
		g3=0;
		g4=0;
		g5=0;
		g6=0;



		for( int d=1; d<=D;d++)
		{
			Matrix x_d = X.Column(d);
			Matrix z_d = Z.Column(d);

			Matrix t_d(K,1);
			t_d=0;
			t_d=T.SubMatrix(1,N,d,d);
			Matrix Sigma_i_t_d = Sigma_inverse*t_d;
			Matrix phi_d = 1/2.0*(Sigma_inverse-Sigma_i_t_d*Sigma_i_t_d.t());
			g1 += -1*(B.t()*Sigma_i_t_d*(x_d-x_avg).t());
			Matrix Sigma_i_t_d_x_d=Sigma_i_t_d*(x_d-x_avg).t();
			Matrix Xi_1 = -1*Sigma_i_t_d_x_d*A.t();
			Matrix Xi_2(N,M);
			Xi_2=2*sigma_1*sigma_1*phi_d*B;
			//for( int i=1;i<=N;i++)
			//	for( int j=1; j<=M; j++)
			//	{
			//		Matrix E(N,M);
			//		E=0;
			//		E(i,j)=1;
			//		Matrix E_B_t=E*B.t();
			//		Xi_2(i,j)=(phi_d*(E_B_t+E_B_t.t())).Trace();
			//		E.Release();
			//		E_B_t.Release();
			//	}
			g2+=Xi_1+Xi_2;

		//	printMatrix(Xi_2);


			g3+=-1*Sigma_i_t_d_x_d;

			g4+=2*tau*(phi_d*Kin).Trace();

			g5+=2*sigma_1*(phi_d*B_B_t).Trace();

			g6+=2*sigma_2*phi_d.Trace();


			x_d.Release();
			z_d.Release();
			Xi_1.Release();
			Xi_2.Release();
			phi_d.Release();
			t_d.Release();
			Sigma_i_t_d.Release();
			Sigma_i_t_d_x_d.Release();

		}


		g4=g4*(tau-minsigma);
		g5=g5*(sigma_1-minsigma);
		g6=g6*(sigma_2-minsigma);


	//	printMatrix(g1);	printMatrix(g2);	printMatrix(g3); cout<<g4<<endl;


		int k=0;

		{for (int j=1;j<=g1.Ncols();j++)
		{
			for (int i=1;i<=g1.Nrows();i++)
			{
				gradient[k] = g1(i,j);
				k++;
			}
		}}

		{for (int j=1;j<=g2.Ncols();j++)
		{
			for (int i=1;i<=g2.Nrows();i++)
			{
				gradient[k] = g2(i,j);
				k++;
			}
		}}

		{for (int j=1;j<=g3.Ncols();j++)
		{
			for (int i=1;i<=g3.Nrows();i++)
			{
				gradient[k] = g3(i,j);
				k++;
			}
		}}

		gradient[k] = g4(1,1);
		gradient[k+1] = g5(1,1);
		gradient[k+2] = g6(1,1);

	//	printDblVec(gradient);

		A.Release(); B.Release();  I_N.Release(); 
		g1.Release(); g2.Release(); g3.Release();g4.Release(); g5.Release();g6.Release();
		x_avg.Release();z_avg.Release();
		Sigma_inverse.Release();
		Sigma.Release();
		I_N.Release();
		T.Release();
		B_B_t.Release();

		return f;




}

