To run the matlab version, please run:
   >> addpath(genpath(pwd)) % Add all directories to the path
   >> mexAll
Then, you can run below as an example:
   >> pre_rec